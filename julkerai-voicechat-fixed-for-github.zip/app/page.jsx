
import { useEffect, useState } from 'react';

export default function Page() {
  const [text, setText] = useState('');
  const [response, setResponse] = useState('');
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      const speechText = event.results[0][0].transcript;
      setText(speechText);
      fetchAIResponse(speechText);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    if (isListening) recognition.start();

    return () => recognition.abort();
  }, [isListening]);

  const fetchAIResponse = async (prompt) => {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer sk-demo1234567890123456789012345678901234'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    const reply = data.choices?.[0]?.message?.content || 'No response';
    setResponse(reply);

    const synth = window.speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(reply);
    synth.speak(utterance);
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>🎤 Talk to Julker AI</h1>
      <button onClick={() => setIsListening(true)} style={{ padding: '1rem', fontSize: '1rem', marginBottom: '1rem' }}>
        🎙️ Speak Now
      </button>
      <div><strong>You said:</strong> {text}</div>
      <div style={{ marginTop: '1rem' }}><strong>Julker AI:</strong> {response}</div>
      <div style={{ marginTop: '2rem' }}>
        <a href="https://ko-fi.com/julkerai" target="_blank" rel="noreferrer">
          ❤️ Support on Ko-fi
        </a>
      </div>
    </div>
  );
}
