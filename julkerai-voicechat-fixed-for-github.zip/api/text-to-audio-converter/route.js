async function handler({ text, language = "en-US", voiceName = null }) {
  try {
    const utterance = new SpeechSynthesisUtterance(text);

    if (language) {
      utterance.lang = language;
    }

    const voices = window.speechSynthesis.getVoices();

    if (voiceName) {
      const selectedVoice = voices.find((voice) => voice.name === voiceName);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
    } else {
      const defaultVoice = voices.find((voice) =>
        voice.lang.startsWith(language)
      );
      if (defaultVoice) {
        utterance.voice = defaultVoice;
      }
    }

    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;

    return new Promise((resolve, reject) => {
      utterance.onend = () => {
        resolve({
          success: true,
          message: "Speech synthesis completed",
        });
      };

      utterance.onerror = (error) => {
        reject({
          success: false,
          error: error.message,
        });
      };

      window.speechSynthesis.speak(utterance);
    });
  } catch (error) {
    return {
      success: false,
      error: error.message,
    };
  }
}